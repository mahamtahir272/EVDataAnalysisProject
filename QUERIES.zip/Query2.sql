#Show the top 5 most expensive electric cars.

select c.ID,c.Brand,c.Model,p1.PRICE
from price p
left join cardata c
on c.ID=p.CarID
join(
select PriceEuro as PRICE
from price
group by PriceEuro
order by PriceEuro desc
limit 5) p1
on p1.PRICE=p.PriceEuro
order by p.PriceEuro desc;

#Display the average efficiency (Wh/km) of cars by body style.

select distinct BodyStyle,avg(EfficiencyWhKm) over (partition by BodyStyle) as AVG_EFFICIENCY
from cardata c
join carspecifications s
on c.ID=s.CarID;


#List the top 3 cars with the highest top speed.
SELECT c.ID, c.Brand, c.Model, s.TopSpeedKmH AS TopSpeed
FROM CarData c
JOIN CarSpecifications s ON c.ID = s.CarID
ORDER BY s.TopSpeedKmH DESC
LIMIT 3;

#Display the percentage of cars with rapid charge capabilities.
WITH total AS (
    SELECT COUNT(*) AS TotalCount
    FROM CarSpecifications
),
Rapid AS (
    SELECT COUNT(*) AS RapidCount
    FROM CarSpecifications
    WHERE RapidCharge = 'Yes'
),
Non_Rapid AS (
    SELECT COUNT(*) AS NonRapidCount
    FROM CarSpecifications
    WHERE RapidCharge = 'No'
)
SELECT
    round((Rapid.RapidCount / total.TotalCount) * 100,2) AS RapidChargePercentage,
    round((Non_Rapid.NonRapidCount / total.TotalCount) * 100,2) AS NonRapidChargePercentage
FROM total
 JOIN Rapid
 JOIN Non_Rapid;
 
 
 #List the cars with the best acceleration (lowest time) and their prices.
with temp as (select AccelerationSec
from carspecifications
group by AccelerationSec
order by AccelerationSec asc
limit 3)

select ID,Brand,Model,t.AccelerationSec,PriceEuro
from cardata c
join price p
on c.ID=p.CarID
join carspecifications s
on c.ID=s.CarID
join temp t
on t.AccelerationSec=s.AccelerationSec
order by t.AccelerationSec asc;

 
 





