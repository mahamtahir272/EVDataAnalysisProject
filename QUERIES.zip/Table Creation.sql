DROP DATABASE IF EXISTS electriccar;
CREATE DATABASE electriccar;
USE electriccar;

CREATE TABLE CarData (
    ID varchar(50) PRIMARY KEY ,
    Brand varchar(50),
    Model varchar(50),
    Seats int,
    BodyStyle varchar(50)
);

CREATE TABLE CarSpecifications (
    SpecID int PRIMARY KEY AUTO_INCREMENT, 
    CarID varchar(50),
    AccelerationSec float,
    TopSpeedKmH int,
    Rangekm int,
    EfficiencyWhKm int,
    FastChargekmH int,
    RapidCharge varchar(5),
    PowerTrain varchar(50),
    PlugType varchar(50),
        FOREIGN KEY (CarID) REFERENCES CarData(ID)
);

CREATE TABLE Price (
    PriceID int PRIMARY KEY AUTO_INCREMENT, 
    CarID varchar(50) ,
    PriceEuro int,
	FOREIGN KEY (CarID) REFERENCES CarData(ID)

);

CREATE TABLE registeredcardata (
    EVDataID int PRIMARY KEY AUTO_INCREMENT, 
    Make varchar(50),
    Model varchar(50),
    County varchar(50),
    City varchar(50),
    State varchar(50),
    PostalCode int,
    ModelYear int,
    ElectricVehicleType varchar(100),
    CleanAlternativeFuelVehicle_Eligibility varchar(100),
    ElectricRange int,
    LegislativeDistrict int,
    DOLVehicleID int
);
