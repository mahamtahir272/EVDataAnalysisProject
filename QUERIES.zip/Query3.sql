#What is the total number of electric vehicles registered in US?

select count(*) as num
from registeredcardata
where DOLVehicleID is not null;

#Which electric vehicle models are the most popular in US?
WITH temp AS (
    SELECT COUNT(*) AS num1, Make, Model
    FROM registeredcardata
    GROUP BY Make, Model
)
SELECT Make, Model, num1 as num_of_registration
FROM temp
ORDER BY num1 DESC
limit 3;

#Which counties have the highest number of electric vehicle registrations?

select count(*)  as num_of_registration,County as Country
from registeredcardata
group by County
order by num_of_registration desc
limit 5;

#Which types of electric vehicles (e.g., Battery Electric, Plug-in Hybrid) are most common?

with temp1 as (
select count(*) as num1
from registeredcardata
where ElectricVehicleType ='Battery Electric Vehicle (BEV)'
), temp2 as (
select count(*) as num2
from registeredcardata
where ElectricVehicleType ='Plug-in Hybrid Electric Vehicle (PHEV)'
) 
select 
case 
when num1>num2 then 'Battery Electric Vehicles are most common'
when num2>num1 then 'Plug-in Hybrid Electric Vehicles are most common'
else 'Both are equally common'
end as Result
from temp1
cross join temp2;

#What is the distribution of electric vehicles by model year?

SELECT ModelYear, COUNT(*) AS VehicleCount
FROM registeredcardata
GROUP BY ModelYear
ORDER BY ModelYear ASC;
