#List all cars with their specifications and prices.

select s.CarID,c.Brand,c.Model,PriceEuro,s.AccelerationSec,s.FastChargekmH,s.PlugType,s.Rangekm,s.RapidCharge,s.TopSpeedKmH
from carspecifications s
inner join price p
on s.CarID=p.CarID
right join cardata c
on c.ID=s.CarID;

#Find the average price of electric cars for each brand.

select c.Brand,round(avg(PriceEuro),2) as AVG_PRICE
from cardata c
left join price p
on c.ID=p.CarID
group by c.Brand
order by AVG_PRICE desc;

#Get all cars that have a range greater than 300 km.

select s.CarID,c.Brand,c.Model,s.Rangekm
from carspecifications s
left join cardata c
on s.CarID=c.ID
where Rangekm>300
order by Rangekm asc ;

#List all registered electric cars along with their city and state.

select EVDataID as REGISTERED_CAR_ID,Make,Model,ModelYear,County as Country,City,State,PostalCode,LegislativeDistrict,DOLVehicleID
from registeredcardata;

